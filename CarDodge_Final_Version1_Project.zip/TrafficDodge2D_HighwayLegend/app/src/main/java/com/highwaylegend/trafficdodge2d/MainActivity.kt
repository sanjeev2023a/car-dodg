package com.highwaylegend.trafficdodge2d

import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.view.Choreographer
import android.view.MotionEvent
import android.view.SoundEffectConstants
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.PathParser
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    companion object {
        // Your Exact Production AdMob Unit IDs
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-5523342544622881/5824022291"
        private const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-5523342544622881/4589550417"

        // Local Persistence Keys
        private const val PREFS_NAME = "car_dodge_v1_final_prefs"
        private const val KEY_HIGH_SCORE = "key_high_score"
        private const val KEY_TOTAL_COINS = "key_total_coins"
        private const val KEY_DEATH_COUNT = "key_death_count"
        private const val KEY_SOUND_ENABLED = "key_sound_enabled"
        private const val KEY_PRIVACY_ACCEPTED = "key_privacy_accepted"

        // Crisp Material Vector Icon Paths (Zero Emojis)
        private const val PATH_VOLUME_ON =
            "M3,9v6h4l5,5V4L7,9H3zm13.5,3c0,-1.77 -1.02,-3.29 -2.5,-4.03v8.05c1.48,-0.73 2.5,-2.25 2.5,-4.02zM14,3.23v2.06c2.89,0.86 5,3.54 5,6.71s-2.11,5.85 -5,6.71v2.06c4.01,-0.91 7,-4.49 7,-8.77s-2.99,-7.86 -7,-8.77z"
        private const val PATH_VOLUME_OFF =
            "M16.5,12c0,-1.77 -1.02,-3.29 -2.5,-4.03v2.21l2.45,2.45c0.03,-0.2 0.05,-0.41 0.05,-0.63zm2.5,0c0,0.94 -0.2,1.82 -0.54,2.64l1.51,1.51C20.63,14.91 21,13.5 21,12c0,-4.28 -2.99,-7.86 -7,-8.77v2.06c2.89,0.86 5,3.54 5,6.71zM4.27,3L3,4.27 7.73,9H3v6h4l5,5v-6.73l4.25,4.25c-0.67,0.52 -1.42,0.93 -2.25,1.18v2.06c1.38,-0.31 2.63,-0.95 3.69,-1.81L19.73,21 21,19.73l-9,-9L4.27,3zM12,4L9.91,6.09 12,8.18V4z"
        private const val PATH_PRIVACY_SHIELD =
            "M12,1L3,5v6c0,5.55 3.84,10.74 9,12 5.16,-1.26 9,-6.45 9,-12V5l-9,-4zm0,10.99h7c-0.53,4.12 -3.28,7.79 -7,8.94V12H5V6.3l7,-3.11v8.8z"
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var soundEngine: ProceduralSoundEngine
    private lateinit var gameView: CarDodgeGameView

    private lateinit var telemetryPill: LinearLayout
    private lateinit var btnSoundToggle: FrameLayout
    private lateinit var btnPrivacyCorner: FrameLayout
    private lateinit var iconSound: ImageView
    private lateinit var iconPrivacyCorner: ImageView
    private lateinit var tvScore: TextView
    private lateinit var tvBest: TextView
    private lateinit var tvCoins: TextView
    private lateinit var tvSpeed: TextView

    private lateinit var privacyPageContainer: FrameLayout
    private lateinit var btnClosePrivacyPage: TextView
    private lateinit var tvPrivacyFullText: TextView

    private lateinit var adViewBanner: AdView
    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var highScore = 0
    private var totalCoins = 0
    private var deathCount = 0
    private var isSoundEnabled = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableFullScreenImmersive()

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        highScore = prefs.getInt(KEY_HIGH_SCORE, 0)
        totalCoins = prefs.getInt(KEY_TOTAL_COINS, 0)
        deathCount = prefs.getInt(KEY_DEATH_COUNT, 0)
        isSoundEnabled = prefs.getBoolean(KEY_SOUND_ENABLED, true)

        soundEngine = ProceduralSoundEngine(isSoundEnabled)

        bindViewsAndStyle()
        setupGameCanvas()
        setupBackNavigation()

        // First-launch Privacy Policy Acceptance Dialog
        if (!prefs.getBoolean(KEY_PRIVACY_ACCEPTED, false)) {
            showFirstLaunchPrivacyDialog()
        } else {
            initializeAdMobAds()
        }
    }

    private fun bindViewsAndStyle() {
        val density = resources.displayMetrics.density
        telemetryPill = findViewById(R.id.telemetryPill)
        btnSoundToggle = findViewById(R.id.btnSoundToggle)
        btnPrivacyCorner = findViewById(R.id.btnPrivacyCorner)
        iconSound = findViewById(R.id.iconSound)
        iconPrivacyCorner = findViewById(R.id.iconPrivacyCorner)
        tvScore = findViewById(R.id.tvScore)
        tvBest = findViewById(R.id.tvBest)
        tvCoins = findViewById(R.id.tvCoins)
        tvSpeed = findViewById(R.id.tvSpeed)

        privacyPageContainer = findViewById(R.id.privacyPageContainer)
        btnClosePrivacyPage = findViewById(R.id.btnClosePrivacyPage)
        tvPrivacyFullText = findViewById(R.id.tvPrivacyFullText)
        adViewBanner = findViewById(R.id.adViewBanner)

        tvBest.text = highScore.toString()
        tvCoins.text = totalCoins.toString()

        telemetryPill.background = makeRoundedBox(Color.parseColor("#D90F172A"), Color.parseColor("#4D38BDF8"), 16f, density)
        btnSoundToggle.background = makeRoundedBox(Color.parseColor("#D90F172A"), Color.parseColor("#4D94A3B8"), 13f, density)
        btnPrivacyCorner.background = makeRoundedBox(Color.parseColor("#D90F172A"), Color.parseColor("#6638BDF8"), 13f, density)
        btnClosePrivacyPage.background = makeRoundedBox(Color.parseColor("#0284C7"), Color.parseColor("#38BDF8"), 12f, density)

        iconPrivacyCorner.setImageDrawable(VectorPathDrawable(PATH_PRIVACY_SHIELD, Color.parseColor("#38BDF8")))
        refreshSoundIcon()

        tvPrivacyFullText.text = buildString {
            append("Privacy Policy for Car Dodge (Version 1.0)\n\n")
            append("1. Minimal Permissions & Data Safety\n")
            append("Car Dodge strictly uses only INTERNET and ACCESS_NETWORK_STATE permissions required to load Google AdMob advertisements. ")
            append("This application never requests or accesses your camera, microphone, contacts, photo gallery, phone state, or GPS location.\n\n")
            append("2. Local Game Data\n")
            append("Your high score and collected gold coins are stored strictly locally on your device using Android SharedPreferences.\n\n")
            append("3. Advertising Policy (Google AdMob)\n")
            append("• App ID: ca-app-pub-5523342544622881~6558519461\n")
            append("• Bottom Banner Ad Unit: ca-app-pub-5523342544622881/5824022291 (Placed in a dedicated non-overlapping bottom bar so gameplay and controls are never obstructed).\n")
            append("• Interstitial Ad Unit: ca-app-pub-5523342544622881/4589550417 (Displayed strictly only on every 3rd Game Over and never during active driving).\n\n")
            append("4. Family & Kids Friendly Design\n")
            append("Gameplay speed starts gentle and gradually increases with player skill. You can control the car anytime using the left Round Steering Wheel, center BRAKE pedal, and right SPEED accelerator pedal.")
        }

        btnSoundToggle.setOnClickListener {
            isSoundEnabled = !isSoundEnabled
            prefs.edit().putBoolean(KEY_SOUND_ENABLED, isSoundEnabled).apply()
            soundEngine.setEnabled(isSoundEnabled)
            refreshSoundIcon()
            soundEngine.playTap()
        }

        // Top-Right Corner Icon opens the dedicated Privacy Policy page
        btnPrivacyCorner.setOnClickListener {
            soundEngine.playTap()
            gameView.isPausedByPrivacyPage = true
            privacyPageContainer.visibility = View.VISIBLE
        }

        btnClosePrivacyPage.setOnClickListener {
            soundEngine.playTap()
            privacyPageContainer.visibility = View.GONE
            gameView.isPausedByPrivacyPage = false
        }
    }

    private fun refreshSoundIcon() {
        val path = if (isSoundEnabled) PATH_VOLUME_ON else PATH_VOLUME_OFF
        val color = if (isSoundEnabled) Color.WHITE else Color.parseColor("#64748B")
        iconSound.setImageDrawable(VectorPathDrawable(path, color))
    }

    private fun makeRoundedBox(fill: Int, stroke: Int, radiusDp: Float, density: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * density
            setColor(fill)
            setStroke((1.4f * density).toInt().coerceAtLeast(1), stroke)
        }
    }

    private fun setupGameCanvas() {
        val container = findViewById<FrameLayout>(R.id.gameCanvasContainer)
        gameView = CarDodgeGameView(
            context = this,
            soundEngine = soundEngine,
            initialCoins = totalCoins,
            initialBest = highScore,
            onTelemetryChange = { score, coins, speedKmh ->
                tvScore.text = score.toString()
                tvSpeed.text = speedKmh.toString()
                if (score > highScore) {
                    highScore = score
                    tvBest.text = highScore.toString()
                }
                if (coins != totalCoins) {
                    totalCoins = coins
                    tvCoins.text = totalCoins.toString()
                    prefs.edit().putInt(KEY_TOTAL_COINS, totalCoins).apply()
                }
            },
            onPlayerCrashed = { finalScore ->
                if (finalScore > highScore) {
                    highScore = finalScore
                    tvBest.text = highScore.toString()
                    prefs.edit().putInt(KEY_HIGH_SCORE, highScore).apply()
                }
                deathCount++
                prefs.edit().putInt(KEY_DEATH_COUNT, deathCount).apply()

                // Full-screen Interstitial Ad triggers strictly every 3rd Game Over (never during driving!)
                if (deathCount % 3 == 0) {
                    showPreloadedInterstitialAd()
                } else {
                    preloadInterstitialAd()
                }
            }
        )
        container.addView(gameView)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (privacyPageContainer.visibility == View.VISIBLE) {
                    privacyPageContainer.visibility = View.GONE
                    gameView.isPausedByPrivacyPage = false
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    // =========================================================================
    // GOOGLE ADMOB MONETIZATION (NON-OVERLAPPING BANNER + EVERY 3RD CRASH INTERSTITIAL)
    // =========================================================================
    private fun initializeAdMobAds() {
        MobileAds.initialize(this) {
            loadBannerAd()
            preloadInterstitialAd()
        }
    }

    private fun loadBannerAd() {
        if (adViewBanner.adUnitId.isNullOrEmpty()) {
            adViewBanner.adUnitId = BANNER_AD_UNIT_ID
        }
        adViewBanner.loadAd(AdRequest.Builder().build())
    }

    private fun preloadInterstitialAd() {
        if (isInterstitialLoading || interstitialAd != null) return
        isInterstitialLoading = true
        InterstitialAd.load(
            this,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            gameView.isPausedByAd = false
                            preloadInterstitialAd()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitialAd = null
                            gameView.isPausedByAd = false
                            preloadInterstitialAd()
                        }

                        override fun onAdShowedFullScreenContent() {
                            gameView.isPausedByAd = true
                        }
                    }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                }
            }
        )
    }

    private fun showPreloadedInterstitialAd() {
        val ad = interstitialAd
        if (ad != null && !isFinishing && !isDestroyed) {
            gameView.isPausedByAd = true
            ad.show(this)
        } else {
            preloadInterstitialAd()
        }
    }

    private fun showFirstLaunchPrivacyDialog() {
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Privacy Policy")
            .setMessage(
                "Welcome to Car Dodge!\n\n" +
                "• This game uses only INTERNET and ACCESS_NETWORK_STATE permissions to display Google AdMob ads.\n" +
                "• No camera, microphone, location, or personal data is ever collected.\n" +
                "• You can view the full Privacy Policy anytime by tapping the shield icon in the top-right corner."
            )
            .setCancelable(false)
            .setPositiveButton("ACCEPT") { dlg, _ ->
                prefs.edit().putBoolean(KEY_PRIVACY_ACCEPTED, true).apply()
                dlg.dismiss()
                enableFullScreenImmersive()
                initializeAdMobAds()
            }
            .create()
        dialog.show()
    }

    private fun enableFullScreenImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableFullScreenImmersive()
    }

    override fun onPause() {
        if (::adViewBanner.isInitialized) adViewBanner.pause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        enableFullScreenImmersive()
        if (::adViewBanner.isInitialized) adViewBanner.resume()
    }

    override fun onDestroy() {
        if (::adViewBanner.isInitialized) adViewBanner.destroy()
        if (::soundEngine.isInitialized) soundEngine.release()
        super.onDestroy()
    }

    // =========================================================================
    // VECTOR ICON DRAWABLE
    // =========================================================================
    private class VectorPathDrawable(pathData: String, tintColor: Int) : Drawable() {
        private val srcPath: Path = PathParser.createPathFromPathData(pathData) ?: Path()
        private val drawPath = Path()
        private val matrix = Matrix()
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = tintColor
        }

        override fun draw(canvas: Canvas) {
            val b = bounds
            if (b.isEmpty) return
            matrix.reset()
            val scale = min(b.width() / 24f, b.height() / 24f)
            matrix.postScale(scale, scale)
            matrix.postTranslate(b.left + (b.width() - 24f * scale) * 0.5f, b.top + (b.height() - 24f * scale) * 0.5f)
            srcPath.transform(matrix, drawPath)
            canvas.drawPath(drawPath, paint)
        }

        override fun setAlpha(alpha: Int) { paint.alpha = alpha; invalidateSelf() }
        override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf; invalidateSelf() }
        @Deprecated("Deprecated in Java")
        override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
    }

    // =========================================================================
    // PROGRAMMATIC SOUND EFFECTS ENGINE (ZERO EXTERNAL AUDIO FILES)
    // =========================================================================
    class ProceduralSoundEngine(@Volatile private var enabled: Boolean) {
        private val executor = Executors.newSingleThreadExecutor()
        private val sampleRate = 44100
        private val tapPcm = buildTapWave()
        private val coinPcm = buildCoinWave()
        private val crashPcm = buildCrashWave()

        fun setEnabled(on: Boolean) { enabled = on }
        fun playTap() { if (enabled) playAsync(tapPcm) }
        fun playCoin() { if (enabled) playAsync(coinPcm) }
        fun playCrash() { if (enabled) playAsync(crashPcm) }

        private fun playAsync(pcm: ShortArray) {
            executor.execute {
                var track: AudioTrack? = null
                try {
                    val bytes = pcm.size * 2
                    track = AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(max(bytes, AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)))
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()
                    track.write(pcm, 0, pcm.size)
                    track.play()
                    Thread.sleep((pcm.size * 1000L) / sampleRate + 30L)
                } catch (_: Exception) {
                } finally {
                    try { track?.stop(); track?.release() } catch (_: Exception) {}
                }
            }
        }

        private fun buildTapWave(): ShortArray {
            val n = (sampleRate * 0.055f).toInt()
            val out = ShortArray(n)
            var ph = 0.0
            for (i in 0 until n) {
                val p = i.toDouble() / n
                val freq = 860.0 - 480.0 * p
                ph += (2.0 * Math.PI * freq) / sampleRate
                out[i] = (sin(ph) * (1.0 - p) * 0.45 * Short.MAX_VALUE).toInt().toShort()
            }
            return out
        }

        private fun buildCoinWave(): ShortArray {
            val n = (sampleRate * 0.15f).toInt()
            val out = ShortArray(n)
            var ph = 0.0
            for (i in 0 until n) {
                val p = i.toDouble() / n
                val freq = if (p < 0.42) 987.77 else 1318.51
                ph += (2.0 * Math.PI * freq) / sampleRate
                out[i] = (sin(ph) * (1.0 - p * 0.85) * 0.50 * Short.MAX_VALUE).toInt().toShort()
            }
            return out
        }

        private fun buildCrashWave(): ShortArray {
            val n = (sampleRate * 0.34f).toInt()
            val out = ShortArray(n)
            val rng = Random(7)
            var ph = 0.0
            var filt = 0.0
            for (i in 0 until n) {
                val p = i.toDouble() / n
                val env = (1.0 - p) * (1.0 - p * 0.5)
                ph += (2.0 * Math.PI * (130.0 - 85.0 * p)) / sampleRate
                filt = filt * 0.78 + rng.nextDouble(-1.0, 1.0) * 0.22
                out[i] = ((sin(ph) * 0.5 + filt * 0.5) * env * 0.75 * Short.MAX_VALUE).toInt().toShort()
            }
            return out
        }

        fun release() { executor.shutdownNow() }
    }

    // =========================================================================
    // 60 FPS 3D-SHADED KID-FRIENDLY RACING ENGINE WITH:
    // - LEFT: ROUND STEERING WHEEL
    // - CENTER: BRAKE PEDAL (SMOOTH STOP)
    // - RIGHT: HOLD-TO-ACCELERATE SPEED PEDAL (SMOOTH COAST ON RELEASE)
    // =========================================================================
    class CarDodgeGameView(
        context: Context,
        private val soundEngine: ProceduralSoundEngine,
        private var coins: Int,
        private var bestScore: Int,
        private val onTelemetryChange: (score: Int, coins: Int, speedKmh: Int) -> Unit,
        private val onPlayerCrashed: (finalScore: Int) -> Unit
    ) : View(context), Choreographer.FrameCallback {

        var isPausedByPrivacyPage = false
        var isPausedByAd = false

        private val density = resources.displayMetrics.density
        private var lastFrameNanos = 0L

        // Highway & Cockpit Layout
        private var roadLeft = 0f
        private var roadRight = 0f
        private var roadWidth = 0f
        private var laneWidth = 0f
        private var roadScrollY = 0f
        private var kerbScrollY = 0f
        private var cockpitTopY = 0f

        // Player Car State
        private var playerX = 0f
        private var playerY = 0f
        private var playerW = 0f
        private var playerH = 0f

        // Smooth Driving Physics (Easy-to-Hard)
        private var currentSpeedPx = 0f
        private var isGasHeld = false
        private var isBrakeHeld = false

        // Multi-Touch Controls State
        private var wheelCenterX = 0f
        private var wheelCenterY = 0f
        private var wheelRadius = 56f * density
        private var wheelAngleDeg = 0f
        private var wheelPointerId = -1
        private var brakePointerId = -1
        private var gasPointerId = -1

        private val brakeRect = RectF()
        private val gasRect = RectF()
        private val playAgainBtnRect = RectF()

        private var score = 0
        private var distAcc = 0f
        private var isGameOver = false

        private data class TrafficVehicle(
            var lane: Int,
            var y: Float,
            var speedFactor: Float,
            var bodyColor: Int,
            var roofColor: Int,
            var isTruck: Boolean,
            var overtaken: Boolean = false
        )

        private data class CoinItem(var lane: Int, var y: Float, var phase: Float)

        private val trafficList = arrayListOf(
            TrafficVehicle(0, -280f, 0.36f, Color.parseColor("#EF4444"), Color.parseColor("#FCA5A5"), false),
            TrafficVehicle(2, -920f, 0.32f, Color.parseColor("#F59E0B"), Color.parseColor("#FDE047"), false),
            TrafficVehicle(3, -1580f, 0.26f, Color.parseColor("#3B82F6"), Color.parseColor("#93C5FD"), true)
        )

        private val coinList = arrayListOf(
            CoinItem(1, -200f, 0f),
            CoinItem(1, -460f, 1.2f),
            CoinItem(2, -780f, 2.4f)
        )

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tempRect = RectF()

        init {
            isClickable = true
            isFocusable = true
            Choreographer.getInstance().postFrameCallback(this)
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (w <= 0 || h <= 0) return

            roadLeft = w * 0.13f
            roadRight = w * 0.87f
            roadWidth = roadRight - roadLeft
            laneWidth = roadWidth / 4f

            // Reserve bottom 148dp of game view for the Cockpit Control Deck
            val cockpitHeight = 148f * density
            cockpitTopY = h - cockpitHeight

            playerW = laneWidth * 0.62f
            playerH = playerW * 1.82f
            if (playerX == 0f) {
                playerX = roadLeft + 1.5f * laneWidth
            }
            playerY = cockpitTopY - playerH * 0.85f

            // 1. Left: Round Steering Wheel
            wheelRadius = min(w * 0.145f, 56f * density)
            wheelCenterX = w * 0.20f
            wheelCenterY = cockpitTopY + cockpitHeight * 0.52f

            // 2. Center: BRAKE Pedal
            val brakeW = w * 0.24f
            val brakeH = 64f * density
            brakeRect.set(
                w * 0.50f - brakeW * 0.5f,
                wheelCenterY - brakeH * 0.5f,
                w * 0.50f + brakeW * 0.5f,
                wheelCenterY + brakeH * 0.5f
            )

            // 3. Right: Hold-to-Accelerate SPEED Pedal
            val gasW = w * 0.24f
            val gasH = 98f * density
            gasRect.set(
                w * 0.81f - gasW * 0.5f,
                wheelCenterY - gasH * 0.5f,
                w * 0.81f + gasW * 0.5f,
                wheelCenterY + gasH * 0.5f
            )

            // Play Again Button inside Game Over Card
            playAgainBtnRect.set(w * 0.22f, h * 0.54f, w * 0.78f, h * 0.63f)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (isPausedByPrivacyPage || isPausedByAd) return true

            val action = event.actionMasked
            val idx = event.actionIndex
            val pid = event.getPointerId(idx)
            val tx = event.getX(idx)
            val ty = event.getY(idx)

            if (isGameOver) {
                if (action == MotionEvent.ACTION_DOWN) {
                    soundEngine.playTap()
                    resetRace()
                }
                return true
            }

            when (action) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val distToWheel = hypot(tx - wheelCenterX, ty - wheelCenterY)
                    if (distToWheel <= wheelRadius * 1.65f) {
                        wheelPointerId = pid
                        updateSteeringWheelAngle(tx)
                    } else if (brakeRect.contains(tx, ty)) {
                        brakePointerId = pid
                        isBrakeHeld = true
                        soundEngine.playTap()
                    } else if (gasRect.contains(tx, ty)) {
                        gasPointerId = pid
                        isGasHeld = true
                        soundEngine.playTap()
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until event.pointerCount) {
                        val id = event.getPointerId(i)
                        if (id == wheelPointerId) {
                            updateSteeringWheelAngle(event.getX(i))
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    if (pid == wheelPointerId || action == MotionEvent.ACTION_CANCEL) {
                        wheelPointerId = -1
                    }
                    if (pid == brakePointerId || action == MotionEvent.ACTION_CANCEL) {
                        brakePointerId = -1
                        isBrakeHeld = false
                    }
                    if (pid == gasPointerId || action == MotionEvent.ACTION_CANCEL) {
                        gasPointerId = -1
                        isGasHeld = false
                    }
                }
            }
            return true
        }

        private fun updateSteeringWheelAngle(touchX: Float) {
            val normalized = ((touchX - wheelCenterX) / wheelRadius).coerceIn(-1f, 1f)
            wheelAngleDeg = normalized * 68f
        }

        private fun resetRace() {
            score = 0
            distAcc = 0f
            currentSpeedPx = 0f
            wheelAngleDeg = 0f
            wheelPointerId = -1
            brakePointerId = -1
            gasPointerId = -1
            isGasHeld = false
            isBrakeHeld = false
            playerX = roadLeft + 1.5f * laneWidth

            trafficList[0].apply { lane = 0; y = -280f * density; overtaken = false }
            trafficList[1].apply { lane = 2; y = -920f * density; overtaken = false }
            trafficList[2].apply { lane = 3; y = -1580f * density; overtaken = false }

            coinList[0].apply { lane = 1; y = -200f * density }
            coinList[1].apply { lane = 1; y = -460f * density }
            coinList[2].apply { lane = 2; y = -780f * density }

            isGameOver = false
            onTelemetryChange(score, coins, 0)
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!isAttachedToWindow) return
            val dt = if (lastFrameNanos == 0L) 0.016f else ((frameTimeNanos - lastFrameNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            lastFrameNanos = frameTimeNanos

            if (!isPausedByPrivacyPage && !isPausedByAd && !isGameOver && width > 0) {
                updateSimulation(dt)
            }
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun updateSimulation(dt: Float) {
            // Easy-to-Hard Maximum Speed Cap: starts gentle (480 dp/s) for kids and grows slowly with score
            val maxSpeedCap = min(1350f * density, (480f + score * 1.4f) * density)

            // Accelerator / Coasting / Brake Physics:
            // - Hold Right SPEED Pedal: smoothly accelerates faster the longer it is held
            // - Release SPEED Pedal: smoothly coasts down to 0
            // - Hold Center BRAKE Pedal: rapidly & smoothly brakes to 0
            when {
                isBrakeHeld -> {
                    currentSpeedPx = max(0f, currentSpeedPx - 1350f * density * dt)
                }
                isGasHeld -> {
                    currentSpeedPx = min(maxSpeedCap, currentSpeedPx + 420f * density * dt)
                }
                else -> {
                    currentSpeedPx = max(0f, currentSpeedPx - 310f * density * dt)
                }
            }

            // Smoothly return steering wheel to 0 deg when finger is lifted
            if (wheelPointerId == -1) {
                wheelAngleDeg *= max(0f, 1f - dt * 10f)
            }

            // Move car laterally based on steering wheel rotation
            val steerFactor = wheelAngleDeg / 68f
            val moveScale = if (currentSpeedPx > 20f * density) 1f else 0.45f
            playerX = (playerX + steerFactor * 390f * density * moveScale * dt).coerceIn(
                roadLeft + playerW * 0.56f,
                roadRight - playerW * 0.56f
            )

            roadScrollY = (roadScrollY + currentSpeedPx * dt) % (76f * density)
            kerbScrollY = (kerbScrollY + currentSpeedPx * dt) % (40f * density)

            distAcc += (currentSpeedPx / density) * dt * 0.018f
            if (distAcc >= 1f) {
                val pts = distAcc.toInt()
                distAcc -= pts
                score += pts
            }

            // Update Spinning Gold Coins
            for (c in coinList) {
                c.phase += dt * 6f
                c.y += currentSpeedPx * 0.85f * dt
                val cx = roadLeft + (c.lane + 0.5f) * laneWidth

                if (abs(cx - playerX) < playerW * 0.72f && abs(c.y - playerY) < playerH * 0.62f) {
                    coins++
                    score += 15
                    soundEngine.playCoin()
                    c.y = -320f * density
                    c.lane = Random.nextInt(4)
                } else if (c.y > cockpitTopY + 60f * density) {
                    c.y = -280f * density
                    c.lane = Random.nextInt(4)
                }
            }

            // Update Traffic Vehicles (Only move forward when player drives forward, keeping kid-friendly spacing)
            if (currentSpeedPx > 5f * density) {
                for (tv in trafficList) {
                    val trafficMove = max(60f * density, currentSpeedPx * (1f - tv.speedFactor))
                    tv.y += trafficMove * dt
                    val tx = roadLeft + (tv.lane + 0.5f) * laneWidth
                    val tvH = if (tv.isTruck) playerH * 1.28f else playerH

                    // Collision Check
                    if (abs(tx - playerX) < playerW * 0.72f && abs(tv.y - playerY) < (playerH + tvH) * 0.39f) {
                        isGameOver = true
                        currentSpeedPx = 0f
                        isGasHeld = false
                        isBrakeHeld = false
                        soundEngine.playCrash()
                        onPlayerCrashed(score)
                        return
                    }

                    // Overtake Score Check
                    if (!tv.overtaken && tv.y - tvH * 0.5f > playerY + playerH * 0.3f) {
                        tv.overtaken = true
                        score += 10
                        soundEngine.playCoin()
                    }

                    if (tv.y > height + tvH) {
                        tv.y = -420f * density - Random.nextInt(220) * density
                        tv.lane = Random.nextInt(4)
                        tv.overtaken = false
                    }
                }
            }

            val displayKmh = ((currentSpeedPx / (1350f * density)) * 220f).toInt()
            onTelemetryChange(score, coins, displayKmh)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            if (w <= 0f || h <= 0f) return

            // 1. Bright Kid-Friendly Green Roadside Grass & Trees
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#22C55E")
            canvas.drawRect(0f, 0f, w, h, paint)

            // 2. Red & White 3D Racing Kerbs (Rumble Strips)
            val kerbW = 10f * density
            val kerbStep = 40f * density
            var ky = -kerbStep + kerbScrollY
            var redToggle = true
            while (ky < h) {
                paint.color = if (redToggle) Color.parseColor("#EF4444") else Color.WHITE
                canvas.drawRect(roadLeft - kerbW, ky, roadLeft, ky + kerbStep * 0.5f, paint)
                canvas.drawRect(roadRight, ky, roadRight + kerbW, ky + kerbStep * 0.5f, paint)
                paint.color = if (redToggle) Color.WHITE else Color.parseColor("#EF4444")
                canvas.drawRect(roadLeft - kerbW, ky + kerbStep * 0.5f, roadLeft, ky + kerbStep, paint)
                canvas.drawRect(roadRight, ky + kerbStep * 0.5f, roadRight + kerbW, ky + kerbStep, paint)
                ky += kerbStep
                redToggle = !redToggle
            }

            // 3. 3D-Shaded Asphalt Highway Surface
            paint.color = Color.parseColor("#334155")
            canvas.drawRect(roadLeft, 0f, roadRight, h, paint)
            paint.color = Color.parseColor("#475569")
            canvas.drawRect(roadLeft + 6f * density, 0f, roadRight - 6f * density, h, paint)

            // 4. Crisp White Scrolling Lane Dividers
            paint.color = Color.parseColor("#F8FAFC")
            val dashH = 36f * density
            val dashPeriod = 76f * density
            for (lane in 1..3) {
                val lx = roadLeft + lane * laneWidth
                var dy = -dashPeriod + roadScrollY
                while (dy < h) {
                    canvas.drawRoundRect(lx - 2.5f * density, dy, lx + 2.5f * density, dy + dashH, 4f, 4f, paint)
                    dy += dashPeriod
                }
            }

            // 5. Draw Spinning 3D Gold Coins
            for (c in coinList) {
                val cx = roadLeft + (c.lane + 0.5f) * laneWidth
                val r = laneWidth * 0.24f
                val spinW = max(4f * density, abs(cos(c.phase)) * r)

                // Coin Shadow
                paint.color = Color.parseColor("#660F172A")
                tempRect.set(cx - r * 0.8f, c.y + r * 0.6f, cx + r * 0.8f, c.y + r * 1.05f)
                canvas.drawOval(tempRect, paint)

                // 3D Gold Rim & Face
                paint.color = Color.parseColor("#B45309")
                tempRect.set(cx - spinW + 3f * density, c.y - r, cx + spinW + 3f * density, c.y + r)
                canvas.drawOval(tempRect, paint)

                paint.color = Color.parseColor("#FACC15")
                tempRect.set(cx - spinW, c.y - r, cx + spinW, c.y + r)
                canvas.drawOval(tempRect, paint)

                paint.color = Color.parseColor("#FEF9C3")
                tempRect.set(cx - spinW * 0.35f, c.y - r * 0.45f, cx + spinW * 0.35f, c.y + r * 0.45f)
                canvas.drawRoundRect(tempRect, 4f, 4f, paint)
            }

            // 6. Draw 3D-Shaded Traffic Vehicles
            for (tv in trafficList) {
                val tx = roadLeft + (tv.lane + 0.5f) * laneWidth
                val tvH = if (tv.isTruck) playerH * 1.28f else playerH
                draw3DCar(canvas, tx, tv.y, playerW, tvH, 0f, tv.bodyColor, tv.roofColor, false)
            }

            // 7. Draw Player 3D-Shaded Supercar
            draw3DCar(
                canvas,
                playerX,
                playerY,
                playerW,
                playerH,
                wheelAngleDeg * 0.22f,
                Color.parseColor("#0284C7"),
                Color.parseColor("#38BDF8"),
                true
            )

            // 8. Draw Bottom Driving Cockpit Deck (Above Banner Ad — Never Covered!)
            drawCockpitControls(canvas, w, h)

            // 9. Draw Friendly Game Over Card if Crashed
            if (isGameOver) {
                drawGameOverCard(canvas, w, h)
            }
        }

        private fun draw3DCar(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            cw: Float,
            ch: Float,
            tiltDeg: Float,
            bodyColor: Int,
            roofColor: Int,
            isPlayer: Boolean
        ) {
            canvas.save()
            canvas.translate(cx, cy)
            if (tiltDeg != 0f) canvas.rotate(tiltDeg)

            val hw = cw * 0.5f
            val hh = ch * 0.5f
            val rad = cw * 0.25f

            // Ground Shadow
            paint.color = Color.parseColor("#770F172A")
            tempRect.set(-hw * 1.08f, -hh * 0.90f, hw * 1.08f, hh * 1.08f)
            canvas.drawRoundRect(tempRect, rad, rad, paint)

            // 4 Protruding Tires
            paint.color = Color.parseColor("#0F172A")
            val tw = cw * 0.12f
            val th = ch * 0.18f
            canvas.drawRoundRect(-hw - tw * 0.5f, -hh + ch * 0.12f, -hw + tw * 0.5f, -hh + ch * 0.12f + th, 4f, 4f, paint)
            canvas.drawRoundRect(hw - tw * 0.5f, -hh + ch * 0.12f, hw + tw * 0.5f, -hh + ch * 0.12f + th, 4f, 4f, paint)
            canvas.drawRoundRect(-hw - tw * 0.5f, hh - ch * 0.30f, -hw + tw * 0.5f, hh - ch * 0.30f + th, 4f, 4f, paint)
            canvas.drawRoundRect(hw - tw * 0.5f, hh - ch * 0.30f, hw + tw * 0.5f, hh - ch * 0.30f + th, 4f, 4f, paint)

            // 3D Chassis Body
            paint.color = bodyColor
            tempRect.set(-hw, -hh, hw, hh)
            canvas.drawRoundRect(tempRect, rad, rad, paint)

            if (isPlayer) {
                paint.color = Color.WHITE
                tempRect.set(-hw * 0.16f, -hh * 0.92f, hw * 0.16f, hh * 0.92f)
                canvas.drawRoundRect(tempRect, 4f, 4f, paint)
            }

            // 3D Cabin & Windshield
            paint.color = Color.parseColor("#0F172A")
            tempRect.set(-hw * 0.76f, -hh * 0.38f, hw * 0.76f, hh * 0.42f)
            canvas.drawRoundRect(tempRect, rad * 0.65f, rad * 0.65f, paint)

            paint.color = roofColor
            tempRect.set(-hw * 0.62f, -hh * 0.10f, hw * 0.62f, hh * 0.32f)
            canvas.drawRoundRect(tempRect, rad * 0.5f, rad * 0.5f, paint)

            // Headlights & Taillights
            paint.color = Color.parseColor("#FEF08A")
            canvas.drawRoundRect(-hw * 0.78f, -hh * 0.96f, -hw * 0.36f, -hh * 0.86f, 3f, 3f, paint)
            canvas.drawRoundRect(hw * 0.36f, -hh * 0.96f, hw * 0.78f, -hh * 0.86f, 3f, 3f, paint)

            paint.color = Color.parseColor("#FB7185")
            canvas.drawRoundRect(-hw * 0.80f, hh * 0.88f, -hw * 0.34f, hh * 0.98f, 3f, 3f, paint)
            canvas.drawRoundRect(hw * 0.34f, hh * 0.88f, hw * 0.80f, hh * 0.98f, 3f, 3f, paint)

            canvas.restore()
        }

        private fun drawCockpitControls(canvas: Canvas, w: Float, h: Float) {
            // Translucent Cockpit Dashboard Base
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#CC0F172A")
            tempRect.set(0f, cockpitTopY, w, h)
            canvas.drawRoundRect(tempRect, 24f * density, 24f * density, paint)

            // 1. LEFT: Round Steering Wheel
            canvas.save()
            canvas.translate(wheelCenterX, wheelCenterY)
            canvas.rotate(wheelAngleDeg)

            // Outer Wheel Grip Shadow & Ring
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 14f * density
            paint.color = Color.parseColor("#1E293B")
            canvas.drawCircle(0f, 0f, wheelRadius, paint)

            paint.strokeWidth = 9f * density
            paint.color = Color.parseColor("#38BDF8")
            canvas.drawCircle(0f, 0f, wheelRadius, paint)

            // Steering Wheel Spokes (Left, Right, Bottom)
            canvas.drawLine(-wheelRadius, 0f, wheelRadius, 0f, paint)
            canvas.drawLine(0f, 0f, 0f, wheelRadius, paint)

            // Top Center Red Racing Marker
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#EF4444")
            canvas.drawCircle(0f, -wheelRadius, 5f * density, paint)

            // Center Horn Hub
            paint.color = Color.parseColor("#0F172A")
            canvas.drawCircle(0f, 0f, wheelRadius * 0.34f, paint)
            paint.color = Color.parseColor("#38BDF8")
            canvas.drawCircle(0f, 0f, wheelRadius * 0.14f, paint)
            canvas.restore()

            // 2. CENTER: 3D Beveled BRAKE Pedal
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#7F1D1D")
            tempRect.set(brakeRect.left, brakeRect.top + 5f * density, brakeRect.right, brakeRect.bottom + 5f * density)
            canvas.drawRoundRect(tempRect, 16f * density, 16f * density, paint)

            paint.color = if (isBrakeHeld) Color.parseColor("#DC2626") else Color.parseColor("#EF4444")
            val bShift = if (isBrakeHeld) 3f * density else 0f
            tempRect.set(brakeRect.left, brakeRect.top + bShift, brakeRect.right, brakeRect.bottom + bShift)
            canvas.drawRoundRect(tempRect, 16f * density, 16f * density, paint)

            paint.color = Color.WHITE
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 15f * density
            canvas.drawText("BRAKE", brakeRect.centerX(), brakeRect.centerY() + 5f * density + bShift, paint)

            // 3. RIGHT: 3D Beveled Hold-to-Accelerate SPEED Pedal
            paint.color = Color.parseColor("#14532D")
            tempRect.set(gasRect.left, gasRect.top + 6f * density, gasRect.right, gasRect.bottom + 6f * density)
            canvas.drawRoundRect(tempRect, 18f * density, 18f * density, paint)

            paint.color = if (isGasHeld) Color.parseColor("#16A34A") else Color.parseColor("#22C55E")
            val gShift = if (isGasHeld) 4f * density else 0f
            tempRect.set(gasRect.left, gasRect.top + gShift, gasRect.right, gasRect.bottom + gShift)
            canvas.drawRoundRect(tempRect, 18f * density, 18f * density, paint)

            // Pedal grip tread lines
            paint.color = Color.parseColor("#4D000000")
            for (i in -1..1) {
                val ly = gasRect.centerY() + i * 18f * density + gShift
                canvas.drawRoundRect(gasRect.left + 14f * density, ly - 2f * density, gasRect.right - 14f * density, ly + 2f * density, 3f, 3f, paint)
            }

            paint.color = Color.WHITE
            paint.textSize = 14f * density
            canvas.drawText("SPEED", gasRect.centerX(), gasRect.centerY() + 5f * density + gShift, paint)
        }

        private fun drawGameOverCard(canvas: Canvas, w: Float, h: Float) {
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#B3090D16")
            canvas.drawRect(0f, 0f, w, h, paint)

            tempRect.set(w * 0.12f, h * 0.24f, w * 0.88f, h * 0.68f)
            paint.color = Color.WHITE
            canvas.drawRoundRect(tempRect, 28f * density, 28f * density, paint)

            paint.color = Color.parseColor("#0F172A")
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.DEFAULT_BOLD
            paint.textSize = 24f * density
            canvas.drawText("GREAT RUN!", w * 0.5f, h * 0.33f, paint)

            paint.color = Color.parseColor("#0284C7")
            paint.textSize = 18f * density
            canvas.drawText("SCORE: $score   •   COINS: $coins", w * 0.5f, h * 0.43f, paint)

            paint.color = Color.parseColor("#22C55E")
            canvas.drawRoundRect(playAgainBtnRect, 18f * density, 18f * density, paint)

            paint.color = Color.WHITE
            paint.textSize = 18f * density
            canvas.drawText("TAP TO PLAY AGAIN", w * 0.5f, playAgainBtnRect.centerY() + 6f * density, paint)
        }
    }
}