# Keep Google Mobile Ads (AdMob) classes
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.**
