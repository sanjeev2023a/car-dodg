# Traffic Dodge 2D: Highway Legend — संपूर्ण हिंदी गाइड (APK और Play Store पब्लिशिंग)

## 1. इस प्रोजेक्ट में क्या-क्या शामिल है?
यह पूरा **Android Studio Project** आपके गेम **"Traffic Dodge 2D: Highway Legend"** का 100% तैयार कोड है:
- **60 FPS स्मूथ गेमप्ले (`MainActivity.kt`)**: बिना किसी बाहरी इमेज या साउंड फाइल के (Zero External Assets) पूरा हाईवे, सुपरकार, हेडलाइट बीम, ट्रैफिक गाड़ियां, और पार्टिकल इफेक्ट्स कोड से (Canvas पर) ड्रॉ होते हैं।
- **प्रोग्रामेटिक साउंड इंजन (`ProceduralSoundEngine`)**: लेन बदलने (`tap`), ओवरटेक/स्कोर बढ़ने (`scoreUp`), और एक्सीडेंट (`crash`) के लिए साउंड इफेक्ट्स अपने-आप कोड से जनरेट होते हैं।
- **AdMob कमाई (Monetization)**:
  - **Banner Ad (`ca-app-pub-5523342544622881/5824022291`)**: स्क्रीन के सबसे नीचे हमेशा दिखता है।
  - **Interstitial Ad (`ca-app-pub-5523342544622881/4589550417`)**: खिलाड़ी को परेशान होने से बचाने के लिए यह विज्ञापन हर बार आउट होने पर नहीं, बल्कि **ठीक हर तीसरी बार आउट होने पर (Every 3rd Game Over)** तुरंत बिना किसी लैग के दिखता है।
- **Privacy Policy और सुरक्षा (`AndroidManifest.xml`)**:
  - केवल `INTERNET` और `ACCESS_NETWORK_STATE` परमिशन ली गई है (कैमरा, लोकेशन या स्टोरेज की कोई परमिशन नहीं)।
  - ऐप पहली बार खुलने पर **Privacy & Data Policy** बॉक्स दिखाता है जिसमें **ACCEPT** बटन दबाने के बाद ही विज्ञापन शुरू होते हैं।

---

## 2. डायरेक्ट इंस्टॉल करने वाला Signed APK और Store पर डालने वाला AAB कैसे बनाएं?

### तरीका A: बिना कंप्यूटर (मोबाइल से) 2 मिनट में Signed APK बनाएं (GitHub Cloud से - बिल्कुल मुफ्त)
अगर आपके पास भारी लैपटॉप या Android Studio नहीं है, तो हमने इस ZIP में **Automatic Cloud APK Builder** (`.github/workflows/build-signed-apk.yml`) जोड़ दिया है:
1. [github.com](https://github.com) पर एक फ्री अकाउंट बनाएं और नया **Repository** बनाएं।
2. इस `TrafficDodge2D_AndroidStudio_Project.zip` के अंदर की सारी फाइलें उस Repository में अपलोड कर दें।
3. ऊपर **Actions** टैब पर क्लिक करें और **Build Signed APK & Play Store AAB** पर जाकर **Run workflow** दबाएं।
4. सिर्फ 2 मिनट में GitHub का सर्वर आपके लिए:
   - `TrafficDodge2D-Signed-Release-APK` (मोबाइल में डायरेक्ट इंस्टॉल करने और किसी भी APK स्टोर जैसे Indus Appstore, Amazon Appstore, Uptodown पर डालने के लिए)
   - `TrafficDodge2D-PlayStore-AAB` (Google Play Store पर डालने के लिए)
   तैयार कर देगा, जिसे आप सीधे डाउनलोड कर सकते हैं!

### तरीका B: कंप्यूटर पर Android Studio से Signed APK (V1 + V2) बनाएं
1. अपने कंप्यूटर में **Android Studio** खोलें और इस ZIP फोल्डर को Extract करके **Open** करें।
2. ऊपर मेन्यू में **Build > Generate Signed App Bundle / APK...** पर जाएं:
   - **Google Play Store** पर अपलोड करना हो तो **Android App Bundle (.aab)** चुनें।
   - **डायरेक्ट मोबाइल में इंस्टॉल** करना हो या अन्य स्टोर पर डालना हो तो **APK** चुनें।
3. **Create new...** पर क्लिक करके अपनी `.jks` Keystore फाइल बनाएं (Validity 25 साल रखें) और **V1 (Jar Signature)** तथा **V2 (Full APK Signature)** दोनों को टिक करके **Create** दबाएं। इससे फोन में कभी भी *"Harmful App"* की चेतावनी नहीं आएगी।

---

## 3. स्टोर पर पब्लिश करने से पहले 1 ज़रूरी बदलाव
`MainActivity.kt`, `activity_main.xml` और `AndroidManifest.xml` तीनों में आपकी असली पब्लिशर ID (`ca-app-pub-5523342544622881`) सेट कर दी गई है:
- **Banner Ad Unit ID**: `ca-app-pub-5523342544622881/5824022291`
- **Interstitial Ad Unit ID**: `ca-app-pub-5523342544622881/4589550417`
- **Manifest App ID**: `ca-app-pub-5523342544622881~5824022291` (यदि आपके AdMob के App Settings में `~` के बाद के 10 अंक अलग हों, तो आप उसे वहां मिला सकते हैं)।
